require("dotenv").config({ path: __dirname + "/.env" });
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const mysql = require("mysql2/promise");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());

console.log("SECRET:", process.env.JWT_SECRET ? "OK cargado" : "FALTA.env");

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "login_db",
  waitForConnections: true,
});

// Servir frontend
app.use(express.static(path.join(__dirname, "../frontend")));

// ===== HELPER TAXIMETRO =====
function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ===================== AUTH ADMIN =====================
app.post("/api/register", async (req, res) => {
  try {
    const { email, password } = req.body;
    const hash = await bcrypt.hash(password, 10);
    await pool.query("INSERT INTO users (email, password) VALUES (?,?)", [
      email,
      hash,
    ]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await pool.query("SELECT * FROM users WHERE email=?", [
      email,
    ]);
    if (!rows.length) return res.status(401).json({ msg: "no existe" });
    const ok = await bcrypt.compare(password, rows[0].password);
    if (!ok) return res.status(401).json({ msg: "pass mal" });
    const token = jwt.sign({ id: rows[0].id, email }, process.env.JWT_SECRET, {
      expiresIn: "8h",
    });
    res.json({ token });
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.get("/api/me", async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    res.json({ user: decoded });
  } catch {
    res.status(401).json({ msg: "no auth" });
  }
});

// ===================== MIDDLEWARE =====================
function verificarToken(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ msg: "no token" });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ msg: "token mal" });
  }
}

function verificarChofer(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ msg: "no token chofer" });
  try {
    const d = jwt.verify(token, process.env.JWT_SECRET);
    if (d.role !== "chofer")
      return res.status(401).json({ msg: "no es chofer" });
    req.chofer = d;
    next();
  } catch {
    return res.status(401).json({ msg: "token mal chofer" });
  }
}

// ===================== CHOFERES (ADMIN) =====================
app.get("/api/choferes", verificarToken, async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT * FROM choferes ORDER BY habilitado_hoy DESC, id DESC",
    );
    res.json(rows);
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.post("/api/choferes", verificarToken, async (req, res) => {
  try {
    const { nombre, telefono, patente, auto_modelo, email, password } =
      req.body;
    if (!nombre || !email || !password)
      return res.status(400).json({ msg: "faltan datos" });
    const hash = await bcrypt.hash(password, 10);
    await pool.query(
      "INSERT INTO choferes (nombre, telefono, patente, auto_modelo, email, password, estado, viajes_hoy, habilitado_hoy, en_linea) VALUES (?,?,?,?,?,?,?,?,?,?)",
      [nombre, telefono, patente, auto_modelo, email, hash, "LIBRE", 0, 1, 0],
    );
    res.json({ ok: true });
  } catch (e) {
    console.log(e);
    res.status(500).json({ msg: e.message });
  }
});

app.put("/api/choferes/:id/habilitar", verificarToken, async (req, res) => {
  try {
    const { habilitado } = req.body;
    await pool.query("UPDATE choferes SET habilitado_hoy=? WHERE id=?", [
      habilitado,
      req.params.id,
    ]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.put("/api/choferes/:id/estado", verificarToken, async (req, res) => {
  try {
    const { estado } = req.body;
    const habilitado = estado === "DESCANSO" ? 0 : 1;
    await pool.query(
      "UPDATE choferes SET estado=?, habilitado_hoy=? WHERE id=?",
      [estado, habilitado, req.params.id],
    );
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

// ===================== PEDIDOS (ADMIN) - SOLO ORIGEN TAXIMETRO =====================
app.get("/api/pedidos", verificarToken, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT p.*, c.nombre as chofer_nombre FROM pedidos p
       LEFT JOIN choferes c ON c.id=p.chofer_id
       ORDER BY p.id DESC LIMIT 100`,
    );
    res.json(rows);
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.post("/api/pedidos", verificarToken, async (req, res) => {
  try {
    const { cliente_nombre, cliente_telefono, origen, origen_lat, origen_lng } =
      req.body;
    if (!origen) return res.status(400).json({ msg: "Falta origen" });
    const [r] = await pool.query(
      "INSERT INTO pedidos (cliente_nombre, cliente_telefono, origen, origen_lat, origen_lng, estado) VALUES (?,?,?,?,?, 'pendiente')",
      [
        cliente_nombre,
        cliente_telefono,
        origen,
        origen_lat || null,
        origen_lng || null,
      ],
    );
    res.json({ id: r.insertId });
  } catch (e) {
    console.log(e);
    res.status(500).json({ msg: e.message });
  }
});

// ===================== CHOFERES - LOGIN Y FLUJO TAXIMETRO =====================
app.post("/api/choferes/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await pool.query("SELECT * FROM choferes WHERE email=?", [
      email,
    ]);
    if (!rows.length) return res.status(401).json({ msg: "chofer no existe" });
    const ok = await bcrypt.compare(password, rows[0].password);
    if (!ok) return res.status(401).json({ msg: "pass mal" });
    const token = jwt.sign(
      { id: rows[0].id, email, role: "chofer" },
      process.env.JWT_SECRET,
      { expiresIn: "8h" },
    );
    res.json({ token, nombre: rows[0].nombre });
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.get("/api/chofer/me", verificarChofer, async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM choferes WHERE id=?", [
      req.chofer.id,
    ]);
    if (!rows.length) return res.status(404).json({ msg: "no existe" });
    const c = rows[0];
    const [viajes] = await pool.query(
      "SELECT * FROM pedidos WHERE chofer_id=? AND DATE(COALESCE(finalizado_at,created_at))=CURDATE() AND estado='finalizado' ORDER BY id DESC",
      [c.id],
    );
    const bruto = viajes.reduce(
      (s, v) => s + Number(v.precio_final || v.precio || 0),
      0,
    );
    const neto = c.habilitado_hoy ? bruto - 4000 : bruto;
    res.json({
      nombre: c.nombre,
      habilitado_hoy: c.habilitado_hoy,
      en_linea: c.en_linea,
      viajes_hoy: viajes.length,
      bruto,
      neto,
      historial: viajes,
    });
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.post("/api/chofer/toggle-linea", verificarChofer, async (req, res) => {
  try {
    await pool.query("UPDATE choferes SET en_linea = NOT en_linea WHERE id=?", [
      req.chofer.id,
    ]);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.get("/api/chofer/pedidos-pendientes", verificarChofer, async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM choferes WHERE id=?", [
      req.chofer.id,
    ]);
    if (!rows.length) return res.json([]);
    if (!rows[0].habilitado_hoy || !rows[0].en_linea) return res.json([]);
    const [pedidos] = await pool.query(
      "SELECT * FROM pedidos WHERE estado='pendiente' ORDER BY id DESC LIMIT 10",
    );
    res.json(pedidos);
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.get("/api/chofer/viaje-actual", verificarChofer, async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT * FROM pedidos WHERE chofer_id=? AND estado IN ('aceptado','en_camino','llego','a_bordo') ORDER BY id DESC LIMIT 1",
      [req.chofer.id],
    );
    res.json(rows[0] || null);
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.post("/api/chofer/aceptar", verificarChofer, async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const { pedido_id } = req.body;
    await conn.beginTransaction();
    const [[pedido]] = await conn.query(
      "SELECT * FROM pedidos WHERE id=? AND estado='pendiente' FOR UPDATE",
      [pedido_id],
    );
    if (!pedido) {
      await conn.rollback();
      return res.status(409).json({ msg: "Ya lo tomó otro chofer" });
    }
    await conn.query(
      "UPDATE pedidos SET estado='aceptado', chofer_id=? WHERE id=?",
      [req.chofer.id, pedido_id],
    );
    await conn.query("UPDATE choferes SET estado='EN VIAJE' WHERE id=?", [
      req.chofer.id,
    ]);
    await conn.commit();
    res.json({ ok: true, pedido });
  } catch (e) {
    try {
      await conn.rollback();
    } catch {}
    res.status(500).json({ msg: e.message });
  } finally {
    conn.release();
  }
});

app.post("/api/chofer/llego", verificarChofer, async (req, res) => {
  try {
    const { pedido_id } = req.body;
    await pool.query(
      "UPDATE pedidos SET estado='llego' WHERE id=? AND chofer_id=?",
      [pedido_id, req.chofer.id],
    );
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.post("/api/chofer/abordo", verificarChofer, async (req, res) => {
  try {
    const { pedido_id, lat, lng } = req.body;
    await pool.query(
      "UPDATE pedidos SET estado='a_bordo', abordo_lat=?, abordo_lng=?, abordo_at=NOW() WHERE id=? AND chofer_id=?",
      [lat, lng, pedido_id, req.chofer.id],
    );
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.post("/api/chofer/pos", verificarChofer, async (req, res) => {
  try {
    const { pedido_id, lat, lng } = req.body;
    const [[ped]] = await pool.query(
      "SELECT * FROM pedidos WHERE id=? AND chofer_id=?",
      [pedido_id, req.chofer.id],
    );
    if (!ped || ped.estado !== "a_bordo") return res.json({ ok: true, km: 0 });
    const km = haversine(ped.abordo_lat, ped.abordo_lng, lat, lng);
    res.json({ ok: true, km: km.toFixed(2) });
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

app.post("/api/chofer/finalizar", verificarChofer, async (req, res) => {
  try {
    const { pedido_id, lat, lng } = req.body;
    const [[ped]] = await pool.query(
      "SELECT * FROM pedidos WHERE id=? AND chofer_id=?",
      [pedido_id, req.chofer.id],
    );
    if (!ped) return res.status(404).json({ msg: "no existe" });
    const km = haversine(
      ped.abordo_lat || lat,
      ped.abordo_lng || lng,
      lat,
      lng,
    );
    const precio = 500 + Math.round(km * 1800);
    await pool.query(
      "UPDATE pedidos SET estado='finalizado', destino_lat=?, destino_lng=?, distancia_km=?, precio_final=?, precio=?, finalizado_at=NOW() WHERE id=?",
      [lat, lng, km, precio, precio, pedido_id],
    );
    await pool.query("UPDATE choferes SET estado='LIBRE' WHERE id=?", [
      req.chofer.id,
    ]);
    res.json({ ok: true, km: km.toFixed(2), precio });
  } catch (e) {
    res.status(500).json({ msg: e.message });
  }
});

// ===================== START =====================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () =>
  console.log(`Central corriendo en http://localhost:${PORT}`),
);
